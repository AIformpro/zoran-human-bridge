from phzoran.core import PontHumainZoran

phz = PontHumainZoran()
print(phz.add_channel("chat"))
print(phz.list_channels())
