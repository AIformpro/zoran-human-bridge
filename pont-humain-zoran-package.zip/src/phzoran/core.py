class PontHumainZoran:
    def __init__(self):
        self.channels = []
    def add_channel(self, name):
        self.channels.append(name)
        return f"Canal ajouté : {name}"
    def list_channels(self):
        return self.channels
