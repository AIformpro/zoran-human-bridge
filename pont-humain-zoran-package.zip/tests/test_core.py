from phzoran.core import PontHumainZoran

def test_add_channel():
    phz = PontHumainZoran()
    res = phz.add_channel("chat")
    assert "Canal ajouté" in res
